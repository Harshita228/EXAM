/*******Author Name: Christy JV Emp Id : 101484 Date: 24.5.2017 ******/
//Purpose: To provide user interface of Video Management for accepting & displaying video details

package com.cg.videomgmt.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.videomgmt.bean.VideoDetails;
import com.cg.videomgmt.exception.VideoException;
import com.cg.videomgmt.helper.CollectionHelper;
import com.cg.videomgmt.helper.DataValidator;

public class Client 
{
	static Scanner sc=new Scanner(System.in);
	static CollectionHelper collectionhelper=null;
	
	//Main method
	public static void main(String[] args)
	{
		String choice;
		collectionhelper=new CollectionHelper();

		while(true)
		{
			//Providing user interface
			System.out.println("Video Management \n***************** \n1. Insert video details\n"
					+ "2. Display videos details\n"+ "3. Exit From System");
			
			System.out.println("\nEnter your choice :");
			choice=sc.next();
			switch(choice)
			{
			
			//Calling entervideoDetails method for getting & displaying video details 
			case "1":entervideoDetails();break;
			case "2":collectionhelper.displayAllvideos();break;
			case "3":System.out.println("Exiting...");System.exit(0);
			default: System.out.println("Please enter correct choice");
			break;
			}
		}
	}
	
	//method for getting & displaying video details
	private static void entervideoDetails() 
	{
		System.out.println("Enter video Name:");
		String videoName=sc.next();
		try 
		{
			//sending input to validatevideoName method for validating video type
			if(DataValidator.validateVideoName(videoName))
			{
				System.out.println("Enter video Type:");
				String videoType=sc.next();
				//sending input to validatevideoType method for validating video name
				if(DataValidator.validateVideoType(videoType))
				{
					System.out.println("Enter video Quantity:");
					String qty=sc.next();
										
					//sending input to validatevideoQuanity method for validating video quantity
					if(DataValidator.validateVideoQuanity(qty))
					{
												
						//Generate  Random Reference Id
						Random ran=new Random();
						long refId=ran.nextInt();
						int quantity = Integer.parseInt(qty);

						//sending valid input data to the constructor of videoDetails class
						VideoDetails cc=new VideoDetails(videoName, 
								videoType, quantity,java.time.LocalDate.now(), 
								refId);
						//adding valid input data of video details to the array list
						collectionhelper.addNewvideo(cc);
						//displaying all the existing video details of the array list
						collectionhelper.displayAllvideos();
					}
					}	
				}
			
		} 
		catch (VideoException e)
		{			
			System.out.println(e.getMessage());
		}		

	}
}
