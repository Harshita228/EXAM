/*******Author Name: Christy JV Emp Id : 101484 Date: 20.5.2017 ******/
//Purpose: To create arraylist for adding & displaying video details

package com.cg.videomgmt.helper;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.time.*;

import com.cg.videomgmt.bean.VideoDetails;


public class CollectionHelper
{
	//creating array list and adding default data
	private  static ArrayList<VideoDetails> videoList=null;
	static
	{
		videoList=new ArrayList<VideoDetails>();
		VideoDetails videoDetails1=new VideoDetails("Perfect","Mp4",8,LocalDate.now(),888088);
		VideoDetails videoDetails2=new VideoDetails("Attention","avi",8,LocalDate.now(),9656544);
		
		videoList.add(videoDetails1);
		videoList.add(videoDetails2);
	}
	
	public CollectionHelper(){}
	
	//adding video details to the array list
	public void addNewvideo(VideoDetails videoDetails) 
	{			
			videoList.add(videoDetails);
			System.out.println("video details added successfully");
	}
	
	public static ArrayList<VideoDetails> gevideoList() {
		return videoList;
	}

	public static void setvideoList(ArrayList<VideoDetails> videoList) {
		CollectionHelper.videoList = videoList;
	}

	//displaying all video details
	public void displayAllvideos()
	{
		Iterator<VideoDetails> videoIt=videoList.iterator();
		VideoDetails tempvideo=null;
		while(videoIt.hasNext())
		{
			tempvideo=videoIt.next();
			System.out.println(tempvideo);			
		}
	}
	
}
