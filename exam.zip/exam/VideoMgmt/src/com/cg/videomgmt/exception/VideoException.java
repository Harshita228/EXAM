/*******Author Name: Christy JV Emp Id : 101484 Date: 24.5.2017 ******/
//Purpose: To define exceptions for invalid input

package com.cg.videomgmt.exception;

public class VideoException extends Exception 
{
	private static final long serialVersionUID = 1L;
	public VideoException()
	{
		super();
	}
	public VideoException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public VideoException(String message, Throwable cause) 
	{
		super(message, cause);
	}
	public VideoException(String message) 
	{
		super(message);			
	}
	public VideoException(Throwable cause) 
	{
		super(cause);			
	}
}

