/*******Author Name: Christy JV Emp Id : 101484 Date: 24.5.2017 ******/
//Purpose: To provide getters and setters for video details

package com.cg.videomgmt.bean;

import java.time.LocalDate;

public class VideoDetails {

	int[] a={3,4,5,6};
	private String videoName;
	private String videoType;
	private int quantityvideo;
	private long referenceId;
	private LocalDate currentDate;

	//default constructor
	public VideoDetails() {

	}
	
	//initializing instance variables
	public VideoDetails(String videoName, String videoType,int quantityvideo, LocalDate currentDate, long referenceId ) {
		this.videoName = videoName;
		this.videoType = videoType;
		this.quantityvideo = quantityvideo;
		this.currentDate = currentDate;
		this.referenceId = referenceId;
	}
	
	//getter for reference id
	public long getReferenceId() {
		return referenceId;
	}
	//setter for reference id
	public void setReferenceId(int referenceId) {
		this.referenceId = referenceId;
	}
	//getter for video name
	public String getvideoName() {
		return videoName;
	}
	//setter for video name
	public void setvideoName(String videoName) {
		this.videoName = videoName;
	}
	//getter for video type
	public String getvideoType() {
		return videoType;
	}
	//setter for video type
	public void setvideoType(String videoType) {
		this.videoType = videoType;
	}
	//getter for video quantity
	public void getQuantityvideo(int quantityvideo) {
		this.quantityvideo = quantityvideo;
	}
	//setter for video quantity
		public int setQuantityvideo() {
			return quantityvideo;
	}
	//setter for current date
	public LocalDate getCurrentDate() {
		return currentDate;
	}
	//setter for current date
	public void setCurrentDate(LocalDate currentDate) {
		this.currentDate = currentDate;
	}
	//displaying video details 
	@Override
	public String toString() {
		return "Asset [Reference Id=" + referenceId + ", video Name="
				+ videoName + ", video Type=" + videoType +", Quantity=" + quantityvideo
				+ ", Entry Date=" + currentDate + "]";
	}
}
