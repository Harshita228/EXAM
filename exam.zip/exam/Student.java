import java.io.*;

class Student implements Serializable  {
	int roll;
	String sname;

	public Student(int r, String s) {
		roll = r;
		sname = s;
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public String toString() {
		return "Roll no is : " + roll + "   Name is : " + sname;
	}
	
	public static void main(String args[])
	{
		Student s1=new Student(101,"Anitha");
	//	System.out.println(s1);
		
		try {
			//write object to a file
			FileOutputStream fos=new FileOutputStream("d:\\Studentdetails.txt");
			ObjectOutputStream oos=new ObjectOutputStream(fos);
			oos.writeObject(s1);
			oos.close();
			
			//read object from a file
			FileInputStream fis=new FileInputStream("d:\\Studentdetails.txt");
			ObjectInputStream ois=new ObjectInputStream(fis);
			Student s2;
			s2=(Student)ois.readObject();
			ois.close();
			System.out.println(s2);
		} 
		
		
		catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
}