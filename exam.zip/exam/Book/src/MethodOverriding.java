
public class MethodOverriding
{
  private void add(int operand1, int operand2)
  {
     System.out.println(operand1 + operand2);
  }
}
public class Overridden extends MethodOverriding
{
  public void show()
  {
     add(10, 12);
  }
   public static void main(String args[])
   {
      Overridden ob = new Overridden();
      ob.show();
   }
}
