package com.registration.bean;

import java.io.Serializable;

public class RegistrationDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int RegistrationID;
	private String fullName;
	private String orgName;
	private String cityState;
	private String mobileNo;
	private String participantType;
	private int fees;

	//constructor for registration details class
	public RegistrationDetails( String name, String organisation, String city, String mobile, String type, int fee)
	{
		fullName = name;
		orgName = organisation;
		cityState = city;
		mobileNo = mobile;
		participantType = type;
		fees = fee;
	}

	public int getRegistrationID() {
		return RegistrationID;
	}
	public void setRegistrationID(int registrationID) {
		RegistrationID = registrationID;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getCityState() {
		return cityState;
	}
	public void setCityState(String cityState) {
		this.cityState = cityState;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getParticipantType() {
		return participantType;
	}
	public void setParticipantType(String participantType) {
		this.participantType = participantType;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}

	public String toString() {
		return "Full Name: " + this.fullName + " \nOrganisational Name: " + this.orgName + "\nCity and State" + this.cityState + "\nMobile No." + this.mobileNo
				+ " \nParticipant Type: " + this.participantType + "\nRegistration Fees" + this.fees + "\nRegistration Id: " + this.RegistrationID;
	}
}
