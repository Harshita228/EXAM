package com.registration.ui;

import java.util.Scanner;
import java.io.*;

import com.registration.service.RegistrationFileHelper;

public class RegistrationClient {
	public static void main(String args[]) throws IOException
	{ 
		RegistrationFileHelper registrationhelper = new RegistrationFileHelper();
		Scanner sc = new Scanner(System.in);

		String choice;
		
			while(true)
			{
				//Providing user interface
				System.out.println("1. Register for the Conference\n2. Read Registration Details from File\n3. Exit");

				System.out.println("\nEnter your choice :");
				choice=sc.next();
				switch(choice)
				{

				//calls the methods as per the user choice
				case "1": registrationhelper.writeRegistrationDetails(null);
				break;
				case "2": registrationhelper.readRegistrationDetailsFromFile();
				break;
				case "3": System.out.println("Exiting...");
				System.exit(0);
				default: System.out.println("Please enter correct choice");
				break;


				}
				
			}
		}
		
	}






