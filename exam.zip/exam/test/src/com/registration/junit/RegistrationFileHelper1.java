package com.registration.junit;
import static org.junit.Assert.fail;

import org.junit.AfterClass;
import org.junit.Test;

public class RegistrationFileHelper1 {
	



	

		@AfterClass
		public static void tearDownAfterClass() throws Exception {
		}

		@Test
		public void test() {
			fail("Not yet implemented"); // TODO
		}

	}
