package com.registration.junit;

import org.testng.annotations.Test;

public class RegistrationFileHelperTestTest {
  @Test
  public void f() {
  }
}
