package com.registration.junit;

import java.io.IOException;

import org.junit.AfterClass;

import org.junit.BeforeClass;
import org.junit.Test;
import com.registration.bean.RegistrationDetails;
import com.registration.service.FileException;
import com.registration.service.RegistrationFileHelper;


public class RegistrationFileHelperTest {

		static RegistrationFileHelper registrationhelper;
		static RegistrationDetails all=null;

		//adding asset details to the array list
		@BeforeClass
		public   static  void beforeClass()
		{
			registrationhelper=new RegistrationFileHelper();
			all=new RegistrationDetails("Harshita Ahuja","IIT","Pune","9878675643","Student",500);		
		}
		
		
		@AfterClass
		public static  void afterClass()
		{		
			 registrationhelper=null;
			all=null;
		}	
		
		//checking whether asset details are present in array list
		@Test 
		public void testwriteRegistrationDetails() throws FileException, IOException
		{
			 registrationhelper.writeRegistrationDetails(all);
		
		}
}
