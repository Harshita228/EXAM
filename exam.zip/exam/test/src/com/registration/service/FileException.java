package com.registration.service;

public class FileException extends Exception {


	// TODO Auto-generated constructor stub

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FileException(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}

}
