package com.registration.service;

import java.util.regex.Pattern;






public class RegistrationValidator {

	public  static  boolean validateName(String assetName)throws FileException
	{
		String assetPattern="[A-Za-z1-9 |, | \t]{6,30}";
		if(Pattern.matches(assetPattern, assetName))
		{
			return true;
		}
		else
		{
			throw new FileException("Name should be minimum 6 alphabets and max 30");
		}
	}

	public  static  boolean validateCity(String assetName)throws FileException
	{
		String assetPattern="[A-Za-z |, | \t]{8,30}";
		if(Pattern.matches(assetPattern, assetName))
		{
			return true;
		}
		else
		{
			throw new FileException("City and state should be minimum 8 alphabets and max 30");
		}
	}

	public  static  boolean validatePhone(String mobile)throws FileException
	{
		String assetPattern="[7|8|9][0-9]{9}";
		if(Pattern.matches(assetPattern, mobile))
		{
			return true;
		}
		else
		{
			throw new FileException("Mobile No. should be only 10-digit number starting with 7 / 8 / 9. Mobile No. should be only 10-digit number starting with 7 / 8 / 9. ");
		}
	}
	
	public  static  boolean validateType(String type)throws FileException
	{
		if(type.equalsIgnoreCase("student")||(type.equalsIgnoreCase("professor")) || (type.equalsIgnoreCase("It professional")))
		{
			return true;
		}
		else
		{
			throw new FileException("Participant Type must be Student/Professor/IT Professional");
		}
	}


	
	
	public  static  boolean validatefees(String type, int fees)throws FileException
	{     
		if(type.equalsIgnoreCase("student") && fees == 500)
		{
			return true;
		}
		
		
		else if(type.equalsIgnoreCase("professor") && fees == 1000)
		{
			return true;
		}
		
		else if(type.equalsIgnoreCase("It professional") && fees == 1500)
		{
			return true;
		}
		
		else
		{
			System.out.println("please enter valid inputs");
		}
		return false;
	}
	
}
