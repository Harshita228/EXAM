package com.registration.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Random;
import java.util.Scanner;

import com.registration.bean.RegistrationDetails;



public class RegistrationFileHelper {

	Scanner scan = new Scanner(System.in);
	/**
	 * @throws IOException
	 */
	public  void writeRegistrationDetails(RegistrationDetails rd) throws IOException
	{
		System.out.println("Enter full Name: ");
		String name =scan.nextLine();
		try 
		{

			if(RegistrationValidator.validateName(name))		
			{
				System.out.println("Enter organisational behaviour");
				String orgname = scan.nextLine();

				System.out.println("Enter city and state");
				String city = scan.nextLine();

				//validation for city and state
				if(RegistrationValidator.validateCity(city))	
				{


					System.out.println("Enter Mobile No.: ");
					String mobile = scan.next();

					//validation for Mobile Number
					if(RegistrationValidator.validatePhone(mobile))	
					{
						System.out.println("Enter Participant Type");
						scan.nextLine();
						String type = scan.nextLine();

						//validation for participant Type
						if(RegistrationValidator.validateType(type))
						{
							System.out.println("Enter Registration Fees");
							int fees = scan.nextInt();
							if(RegistrationValidator.validatefees(type, fees))
							{
								try {
									RegistrationDetails mb = new RegistrationDetails(name,orgname,city,mobile,type,fees);

									// write object to file
									FileOutputStream fos = new FileOutputStream("ConferenceRegistration.obj");
									ObjectOutputStream oos = new ObjectOutputStream(fos);
									oos.writeObject(mb);
									oos.close();
									Random ran=new Random();

									String refId = String.format("%04d", ran.nextInt(10000));
									int id= Integer.parseInt(refId);

									System.out.println("Your Registration is recorded with Registration ID "+id);

								}		catch (IOException e) {
									e.printStackTrace();
								}
							}
						}
					}
				}
			}
		}

		catch (FileException e)
		{			
			System.out.println(e.getMessage());
		}		

	}

	public void readRegistrationDetailsFromFile() throws IOException
	{



		// read object from file
		try
		{
			FileInputStream fis = new FileInputStream("ConferenceRegistration.obj");
			ObjectInputStream ois = new ObjectInputStream(fis);
			RegistrationDetails result = (RegistrationDetails) ois.readObject();
			ois.close();

			System.out.println("Name: " + result.getFullName() +"\nOrgannisation Name: "+result.getOrgName() +"\nCity & State: "+result.getCityState() +"\nMobile No.: "+result.getMobileNo() +"\nParticipant Type:" +result.getParticipantType() 
					+"\nRegistration Fees: "+result.getFees());

		} catch (FileNotFoundException e) {
			System.out.println("File not found please check after some time");
		} catch (IOException e) {
			System.out.println("OOPS!!. \n Please check after sometime.");;
		} catch (ClassNotFoundException e) {
			System.out.println("404 error not found. \n Please check after sometime.");
		}

	}
}


