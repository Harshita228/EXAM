package com.admission.service;

import com.admission.bean.AdmissionDetails;

import java.util.ArrayList;
import java.util.Iterator;


public class AdmissionFileHelper {
	
		//creating array list and adding default data
		private  static ArrayList<AdmissionDetails> AdmList=null;
		String n;
		static
		{
			AdmList=new ArrayList<AdmissionDetails>();
			
			AdmissionDetails admdetails1 = new AdmissionDetails(01,"Harshita","Ahuja","9891919780","harshita@gmail.com","Science",89.9);
			AdmissionDetails admdetails2 = new AdmissionDetails(02,"Geetika","Goyal","8536740231","geetika@gmail.com","computer",91.8);
			
			
			AdmList.add(admdetails1);
			AdmList.add(admdetails2);
			
			
		}
		public static ArrayList<AdmissionDetails> getAdmList() {
			return AdmList;
		}

		public void DisplayDetails()
		{
			Iterator<AdmissionDetails> admIt=AdmList.iterator();
			AdmissionDetails temp=null;
			while(admIt.hasNext())
			{
				temp=admIt.next();
				System.out.println(temp);			
			}
		}
		
		public void addNewdetails(AdmissionDetails admdetails) 
		{			
				AdmList.add(admdetails);
				System.out.println("Your Admission Details are successfully recorded with Admission ID- "+admdetails.getID());
				
				
				}
		
	public static boolean DeleteDetails(String mobile){
		boolean deleted =false;
		Iterator<AdmissionDetails> itr = AdmList.iterator();
		AdmissionDetails ad = null;
		while(itr.hasNext()){
			ad=itr.next();
			if(ad.getMobileNo().equals(mobile)){
				itr.remove();
				deleted=true;
			}
			else{
				deleted=false;
			}
		}
		return deleted;	
		}

	
	public static boolean find(String mobile1){
		boolean found =false;
		Iterator<AdmissionDetails> itr = AdmList.iterator();
		AdmissionDetails ad = null;
		while(itr.hasNext()){
			ad=itr.next();
			if(ad.getMobileNo().equals(mobile1)){
				
				found=true;
			}
			else{
				found=false;
			}
		}
		return found;	
		}

}
		
			
			
		

