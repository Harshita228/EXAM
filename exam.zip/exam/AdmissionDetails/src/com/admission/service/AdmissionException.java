package com.admission.service;

public class AdmissionException extends Exception {

	public AdmissionException(String string) {
		super(string);		
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
