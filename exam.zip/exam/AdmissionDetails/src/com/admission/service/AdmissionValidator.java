package com.admission.service;

import java.util.regex.Pattern;




import com.admission.service.AdmissionException;


public class AdmissionValidator {

	
		//validating Video name - it should be alphanumeric and minimum 3 characters
		public  static  boolean validateFirstName(String assetName) throws AdmissionException
		{
			String assetPattern="[A-Za-z]{3,15}";
			if(Pattern.matches(assetPattern, assetName))
			{
				return true;
			}
			else
			{
				throw new AdmissionException("First Name should be minimum 3 alphabets and max 15 alphabets");
			}
		}
		
		public  static  boolean validateLastName(String assetName) throws AdmissionException
		{
			String assetPattern="[A-Za-z]{3,15}";
			if(Pattern.matches(assetPattern, assetName))
			{
				return true;
			}
			else
			{
				throw new AdmissionException("Last Name should be minimum 3 alphabets and max 15 alphabets");
			}
		}
		
			public  static  boolean validateStream(String stream)throws AdmissionException
		{
			if(stream.equalsIgnoreCase("Computer Science")||(stream.equalsIgnoreCase("Information Technology")))
			{
				return true;
			}
			else
			{
				throw new AdmissionException("Stream must be either Computer Science or Information Technology");
			}
		}
			
		public  static  boolean validatemarks(double marks) throws AdmissionException
		{
			String assetPattern="[0-9]{1,}[.]{1}[0-9]{0,}";
			if(Pattern.matches(assetPattern, marks+""))
			{
				return true;
			}
			else
			{
				throw new AdmissionException("Aggregate marks will only accept digits");
			}
		}
		
		public  static  boolean validateEmail(String mail)throws AdmissionException
		{
			String assetPattern="^(.+)@(.+)$";
			if(Pattern.matches(assetPattern, mail))
			{
				return true;
			}
			else
			{
				throw new AdmissionException("Email id should contain @ and . symbol.");
			}
		}
		
		public  static  boolean validatePhone(String mobile)throws AdmissionException
		{
			String assetPattern="[7|8|9][0-9]{9}";
			if(Pattern.matches(assetPattern, mobile))
			{
				return true;
			}
			else
			{
				throw new AdmissionException("Mobile No. should be only 10-digit number starting with 7 / 8 / 9. Mobile No. should be only 10-digit number starting with 7 / 8 / 9. ");
			}
		}
}

