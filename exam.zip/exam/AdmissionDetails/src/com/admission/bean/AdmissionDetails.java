package com.admission.bean;

public class AdmissionDetails {

		private long ID;
		private String firstName;
		private String lastName;
		private String mobileNo;
		private String email;
		private String stream;
		private double aggMarks;

public AdmissionDetails(long refId, String firstName2, String lastName2,
		String mobileNo2, String email2, String stream2, double marks) {
		ID = refId;
		firstName = firstName2;
		lastName = lastName2;
		mobileNo = mobileNo2;
		email = email2;
		stream = stream2;
		aggMarks = marks;
	
}




public long getID() {
	return ID;
}

public void setID(long iD) {
	ID = iD;
}


public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getMobileNo() {
	return mobileNo;
}

public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getStream() {
	return stream;
}

public void setStream(String stream) {
	this.stream = stream;
}

public double getAggMarks() {
	return aggMarks;
}

public void setAggMarks(double aggMarks) {
	this.aggMarks = aggMarks;
}

public String toString() {
	return "Asset [Reference Id= " + ID + ", First Name= "
			+ firstName + ", Last Name=  " + lastName +", Contact No.= " + mobileNo
			+ ", Email ID= " + email + ", Stream= " +stream + ", Aggregate Marks= "+aggMarks+"]";
}

}