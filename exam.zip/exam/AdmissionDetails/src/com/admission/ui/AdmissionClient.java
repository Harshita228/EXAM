package com.admission.ui;

import java.util.Random;
import java.util.Scanner;

import com.admission.bean.AdmissionDetails;
import com.admission.service.AdmissionException;
import com.admission.service.AdmissionFileHelper;
import com.admission.service.AdmissionValidator;





public class AdmissionClient {


	static Scanner sc=new Scanner(System.in);
	static Scanner scan = new Scanner(System.in);
	static AdmissionFileHelper admhelper = null;
	int mobile;


	//Main method
	public static void main(String[] args)
	{
		String choice;
		admhelper = new AdmissionFileHelper();
		while(true)
		{
			//Providing user interface
			System.out.println(" 1. Enter admission details \n 2. Display admission details \n 3. Delete admission details based on mobile number \n 4. Find the number of admissions done \n 5. Exit");


			System.out.println("\nEnter your choice :");
			choice=sc.next();
			switch(choice)
			{

			//Calling enterBookDetails method for getting & displaying book details 
			case "1":enterAdmissionDetails();break;
			case "2":admhelper.DisplayDetails();
			break;
			case "3":
				System.out.println("Enter Mobile No");
				String mobile=scan.next();
				if( admhelper.DeleteDetails(mobile))
				{
					System.out.println("Record deleted successfully");
				}
				else
					System.out.println("Record not found");
				break;
			case "4":
				System.out.println("Enter Mobile No");
				String mobile1=scan.next();
				if(admhelper.find(mobile1))
				{
					System.out.println("Record Found");
				}
				else
				{
					System.out.println("Not found");
				}

				break;
			case "5":System.out.println("Exiting...");
			System.exit(0);
			default: System.out.println("Please enter correct choice");
			break;


			}
		}
	}



	private static void enterAdmissionDetails() 
	{
		System.out.println("Enter First Name :");
		String firstName=sc.next();

		try 
		{
			//sending input to validatevideoName method for validating video type
			if(AdmissionValidator.validateFirstName(firstName))
			{

				System.out.println("Enter Last Name :");
				String lastName=sc.next();
				if(AdmissionValidator.validateLastName(lastName))
				{
					System.out.println("Enter Contact Number :");
					String number=sc.next();{
						if(AdmissionValidator.validatePhone(number))
						{
							System.out.println("Enter email Id :");
							String email = sc.next();
							if(AdmissionValidator.validateEmail(email))	
							{
								
								System.out.println("Enter Stream :");
								sc.nextLine();
								String stream = sc.nextLine();
								

									if(AdmissionValidator.validateStream(stream))
								{	
								System.out.println("Enter Aggregate in qualifying exam :");
								double marks = sc.nextDouble();

								if(AdmissionValidator.validatemarks(marks))
								{			
									//Generate  Random Reference Id
									Random ran=new Random();

									String refId = String.format("%04d", ran.nextInt(10000));
									int id= Integer.parseInt(refId);

									//sending valid input data to the constructor of videoDetails class
									AdmissionDetails cc = new AdmissionDetails(id, firstName, lastName, number, email, stream, marks);



									//adding valid input data of video details to the array list
									admhelper.addNewdetails(cc);



								}
							}
						}
					}
				}
			}
		}
	}
			//}

			catch (AdmissionException e)
			{			
				System.out.println(e.getMessage());
			}		

		}



	}


